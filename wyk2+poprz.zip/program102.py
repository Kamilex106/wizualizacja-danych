import matplotlib.pyplot as plt
import pandas as pd



# df = pd.read_csv('video_game_sales.csv')
# print(df.head())
#
# print(df.shape)
#
# print(df.info())
#
# print(df['Platform'].unique())
#
# sales_by_platform = df.groupby('Platform')['Global_Sales'].sum()
# print(sales_by_platform)
#
# high_sales = df[df['Global_Sales'] > 10]
# print(high_sales)
#
# avg_sales_by_genre = df.groupby('Genre')['NA_Sales'].mean()
# print(avg_sales_by_genre)
#
# recent_games = df[df['Year'] > 2005]
# print(recent_games)
#
# unique_games_by_publisher = df.groupby('Publisher')['Name'].nunique()
# print(unique_games_by_publisher)
#
# gta_games = df[df['Name'].str.contains('Grand Theft Auto')]
# print(gta_games)
#

# df = pd.read_csv('video_game_sales.csv')
# sales_df = df[['Rank', 'NA_Sales', 'EU_Sales', 'JP_Sales', 'Other_Sales']]
#
# sales_df.plot(x='Rank')
# #plt.savefig('video_game_sales_plot.png')
# plt.show()
#


import pandas as pd

df = pd.read_csv('cryptocurrency_prices.csv')
df_btc = df[df['Symbol'] == 'BTC']

df = pd.read_csv('cryptocurrency_prices.csv')
df['Date'] = pd.to_datetime(df['Date'])
df_last_year = df[df['Date'] >= '2022-05-08']
print(df_last_year)

df = pd.read_csv('cryptocurrency_prices.csv')
df['Date'] = pd.to_datetime(df['Date'])
df_first_quarter_2023 = df[(df['Date'] >= '2023-01-01') & (df['Date'] < '2023-04-01')]
print(df_first_quarter_2023)

df = pd.read_csv('cryptocurrency_prices.csv')
df_grouped = df.groupby('Symbol')['Close'].mean()


df = pd.read_csv('cryptocurrency_prices.csv')
df['Year'] = pd.DatetimeIndex(df['Date']).year
df_grouped = df.groupby(['Year', 'Symbol'])['Close'].mean()



df = pd.read_csv('cryptocurrency_prices.csv')
df_grouped = df.groupby('Symbol').size()
print(df_grouped)

df = pd.read_csv('cryptocurrency_prices.csv')
df['Year'] = pd.DatetimeIndex(df['Date']).year
df_grouped = df.groupby(['Year', 'Symbol'])['Volume'].sum()
print(df_grouped)





df = pd.read_csv('cryptocurrency_prices.csv')
df['Date'] = pd.to_datetime(df['Date'])
df['Year'] = pd.DatetimeIndex(df['Date']).year
df_grouped = df.groupby(['Year', 'Symbol']).tail(1)
print(df_grouped)


df = pd.read_csv('cryptocurrency_prices.csv')
df_high = df[df['High'] > 10000]
print(df_high)




# data = pd.read_csv('cryptocurrency_prices.csv')
# btc_data = data.loc[data['Symbol'] == 'BTC']
# plt.plot(btc_data['Date'], btc_data['Close'])
# plt.title('Bitcoin Close Price')
# plt.xlabel('Date')
# plt.ylabel('Price ($)')
# plt.show()
