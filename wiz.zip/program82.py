# import numpy as np
#
# A = np.array([[1, 1, 2], [2, 1, 0], [4, 1, 2]])
# B = np.array([[2, 5, 7], [2, 8, 0], [4, 3, 1]])
# C = A + B      # element wise addition
# print(C)
#
# print("\n")
# D = A.dot(B)
# print(D)
#
# print("\n")
#
# print(A.transpose())
#
# print("\n")
#
# print(np.linalg.inv(A))
# print("\n")
#
#
# print(A ** 5)
# print("\n")
#
# print(np.linalg.det(A))
#
# print("\n")
#
# print(B**(1/3))
#
#


import numpy as np

A = np.array([[1, 1, 2],
              [2, 1, 0],
              [4, 1, 2]])

B = np.array([[2, 5, 7],
              [2, 8, 0],
              [4, 3, 1]])

# A + B
A_plus_B = np.add(A, B)
print("A + B:\n", A_plus_B)

# A · B
A_dot_B = np.dot(A, B)
print("A · B:\n", A_dot_B)

# Iloczyn po-elementowi A i B
elementwise_product = np.multiply(A, B)
print("Iloczyn po-elementowi A i B:\n", elementwise_product)

# A transponowana (A.T)
A_transposed = A.T
print("A transponowana:\n", A_transposed)

# Odwrotność A (A^-1)
A_inverse = np.linalg.inv(A)
print("Odwrotność A:\n", A_inverse)

# Elementy A do 5-tej potęgi
A_elementwise_power_5 = np.power(A, 5)
print("Elementy A do 5-tej potęgi:\n", A_elementwise_power_5)

# A do piątej potęgi (A^5)
A_power_5 = np.linalg.matrix_power(A, 5)
print("A do piątej potęgi:\n", A_power_5)

# Wyznacznik B (det B)
B_determinant = np.linalg.det(B)
print("Wyznacznik B:", B_determinant)

# B do -3 potęgi (B^-3)
B_power_minus_3 = np.linalg.matrix_power(B, -3)
print("B do -3 potęgi:\n", B_power_minus_3)

import numpy as np

C = np.array([[1],
              [2],
              [4]])

D = np.array([2, 5, 7])

# C · D
C_dot_D = np.dot(C, D.reshape(1, -1))
print("C · D:\n", C_dot_D)

# D · C
D_dot_C = np.dot(D.reshape(-1, 1), C.reshape(1, -1))
print("D · C:\n", D_dot_C)

# Iloczyn po-elementowy C i D nie jest możliwy, ponieważ mają różne kształty.

# Suma C i D nie jest możliwa, ponieważ mają różne kształty.

E = np.array([[1, 5],
              [2, 1]])

F = np.array([[2, 1],
              [2, 8]])

# E / F
E_div_F = np.divide(E, F)
print("E / F:\n", E_div_F)

# E // F
E_floor_div_F = np.floor_divide(E, F)
print("E // F:\n", E_floor_div_F)

# E % F
E_mod_F = np.mod(E, F)
print("E % F:\n", E_mod_F)

import numpy as np

countries = np.array(['China', 'Japan', 'Germany', 'USA', 'South Korea', 'India', 'Brazil', 'Mexico', 'Spain', 'Russia'])
production_1999 = np.array([0.56, 8.1,5.3,5.63,2.36,0.53,1.1,0.99,2.28,0.94])
production_2014 = np.array([19.91,8.27,5.6,4.25,4.12,3.15,2.31,1.91,1.89,1.69])

print()

production_growth_percentage = ((production_2014 - production_1999) / production_1999) * 100
print("Wzrost produkcji samochodów w procentach:")
for country, growth in zip(countries, production_growth_percentage):
    print(f"{country}: {growth:.2f}%")

# Które państwa z podanych produkowało najmniej oraz najwięcej samochodów w 1999 oraz w 2014 latach
min_prod_1999_country = countries[np.argmin(production_1999)]
max_prod_1999_country = countries[np.argmax(production_1999)]
min_prod_2014_country = countries[np.argmin(production_2014)]
max_prod_2014_country = countries[np.argmax(production_2014)]


print(f"Najmniej samochodów w 1999: {min_prod_1999_country}")
print(f"Najwięcej samochodów w 1999: {max_prod_1999_country}")
print(f"Najmniej samochodów w 2014: {min_prod_2014_country}")
print(f"Najwięcej samochodów w 2014: {max_prod_2014_country}")

# Wybierz państwa, które wyprodukowały w 2014 mniej samochodów niż w 1999
less_prod_2014 = countries[production_2014 < production_1999]
print("Państwa z niższą produkcją samochodów w 2014 niż w 1999:", ', '.join(less_prod_2014))




