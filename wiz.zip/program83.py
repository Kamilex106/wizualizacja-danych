import numpy as np

# Dane wejściowe
dane = np.array([
    ['Anna', 'K', 25, 168, 55, 0],
    ['Tomasz', 'M', 32, 180, 75, 1],
    ['Kasia', 'K', 29, 162, 58, 1],
    ['Piotr', 'M', 24, 178, 64, 0],
    ['Agnieszka', 'K', 23, 170, 68, 0],
    ['Adam', 'M', 27, 175, 62, 0],
], dtype=object)

# Wypisz na konsoli imiona posortowane alfabetycznie
imiona_posortowane = np.sort(dane[:, 0])
print(imiona_posortowane)

# Stwórz tablicę przechowującą imiona osób noszących okulary
nosza_okulary = dane[dane[:, 5] == 1]
imiona_nosza_okulary = nosza_okulary[:, 0]
print(imiona_nosza_okulary)

# Stwórz tablicę zawierającą imiona kobiet w wieku z przedziału lat [20, 30]
kobiety_20_30 = dane[(dane[:, 1] == 'K') & (dane[:, 2] >= 20) & (dane[:, 2] <= 30)]
imiona_kobiety_20_30 = kobiety_20_30[:, 0]
print(imiona_kobiety_20_30)

# Stwórz tablicę zawierającą imiona osób o wadze z przedziału [60, 80], wzroście [160, 180] nienoszących okularów
osoby_bez_okularow_60_80_160_180 = dane[(dane[:, 3] >= 60) & (dane[:, 3] <= 80) & (dane[:, 4] >= 160) & (dane[:, 4] <= 180) & (dane[:, 5] == 0)]
imiona_osoby_bez_okularow_60_80_160_180 = osoby_bez_okularow_60_80_160_180[:, 0]
print(imiona_osoby_bez_okularow_60_80_160_180)

# Policz BMI dla wszystkich osób i wynik zapisz w tablicy
waga = dane[:, 4].astype(float)
wzrost = dane[:, 3].astype(float)
bmi = waga / (wzrost / 100) ** 2
print(bmi)

# Policz średni wiek i wyświetl na konsoli imię osoby najbliżej średniej
wiek = dane[:, 2].astype(int)
sredni_wiek = np.mean(wiek)
najblizsza_osoba = dane[np.argmin(np.abs(wiek - sredni_wiek)), 0]
print(najblizsza_osoba)


