import numpy as np
import pandas as pd

#a)

s = pd.Series([3, -5, 7, 4])
print(s)
print("values")
print(s.values)
print("\n")


s2 = pd.Series(["kwiat","kolo","komputer"])
print(s2)
print(s2.values)
print("\n")

l = ["jeden","dwa","trzy"]
s3 = pd.Series(l)
print(s3)
print(s3.values)

print("\n")

l2 = list(s3)
print(l2)

print("\n")

tab = np.array([3, 4, 5, 3, 2, 9])
s4= pd.Series(tab)
print(s4)
print(s4.values)
print("\n")


tab2 = np.array(s4)
print(tab2)
print("\n")


d = {'key1': 350, 'key2': 700, 'key3': 70}
k = ['key2', 'key3', 'key1']
s5 = pd.Series(d, index=k)

d = {'key1': 100, 'key2': 200, 'key3': 300}
k = ['key2', 'key3', 'key1']
s6 = pd.Series(d, index=k)
print(s5+s6)
print("\n")
print(s5-s6)
print("\n")
print(s5*s6)
print("\n")
print(s5/s6)
print("\n")


random_series = pd.Series(np.random.uniform(-10, 10, 10).round(1))
print(random_series)


#b)

my_list = [1, 32, -37, 91, 12, 11, -5]
my_dict = {'a' : [1, 3, 2], 'b' : [2, 5, 7], 'c' : [3, 4, 8], 'd': [4, 10, 12]}
my_array = np.array([[1, 2, 5],[-2, 3, 3], [5, 2, 6]])
my_series = pd.Series ([1, 32, -37, 91, 12, 11, -5],index = ['a','b','c','d','e','f','g'])


data = {'Country': ['Belgium', 'India', 'Brazil'],
        'Capital': ['Brussels', 'New Delhi', 'Brasília'],
        'Population': [11190846, 1303171035, 207847528]}

#df = pd.DataFrame(data, columns=['Country', 'Population', 'Capital'])
frame = pd.DataFrame(data)
print(frame)
print("\n")
#frame2 = pd.DataFrame(my_list)
frame2 = pd.DataFrame(my_list, columns=['lista'])
print(frame2)
print("\n")
frame3 = pd.DataFrame(my_dict)
print(frame3)
print("\n")
frame4 = pd.DataFrame(my_array)
print(frame4)
print("\n")
frame5 = pd.DataFrame(my_series)
print(frame5)
print("\n")

my_list1= frame2.values.tolist()
print(my_list1)

my_dict1 = frame3.to_dict()
print(my_dict1)

my_array1 = frame4.to_numpy()
print(my_array1)

my_series1 = frame5.squeeze()
print(my_series1)

#c)
#
# data2 = {'a': ['l1', 'l2', 'l3'],
#         'b': ['1', '2', '3'],
#         'c': [2, 8, -5],
#         'd': [4,0.5,7],
#          '': [5,10,3]}
#
#
# #print(pd.DataFrame(data2))
#
# df2 = pd.DataFrame(data2)
#
# print(df2.to_string(index=False))
# df = pd.DataFrame(data, index=index)
#
# element = df.loc["l1", "a"]
# row = df.loc["l1

data = {
    "a": [1, -3, 2],
    "b": [2, 8, -5],
    "c": [4, 0.5, 7],
    "d": [5, 10, 3],
}
index = ["l1", "l2", "l3"]
df = pd.DataFrame(data, index=index)
# Wyciągnięcie elementów
element = df.loc["l1", "a"]
row = df.loc["l1"]
column = df["a"]

# Sortowanie w kolumnie
sorted_by_column_b = df.sort_values(by="b")

# Zmiana kształtu ramki danych (transpozycja)
transposed_df = df.T

# Wydrukuj wyniki
print("Element:")
print(element)
print("\nRow:")
print(row)
print("\nColumn:")
print(column)
print("\nSorted by column 'b':")
print(sorted_by_column_b)
print("\nTransposed DataFrame:")
print(transposed_df)