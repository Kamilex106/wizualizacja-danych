class Polynomial:
    def __init__(self, coef):
        self.coef = coef

    def __str__(self):
        s = ""
        for i in range(len(self.coef)-1, 0, -1):
            s += str(self.coef[i])+("x^")+str(i)
            if self.coef[i-1]>=0:
                s+='+'
        s += str(self.coef[0])
        return (s)

    def __add__(self, other):
        s = []
        if len(self.coef) > len(other.coef):
           for i in range(0, len(other.coef)):
               s.append(self.coef[i]+other.coef[i])
           for i in range(len(other.coef), len(self.coef)):
               s.append(self.coef[i])
        else:
            for i in range(0, len(self.coef)):
                s.append(self.coef[i] + other.coef[i])
            for i in range(len(self.coef), len(other.coef)):
                s.append(other.coef[i])
        return Polynomial(s)

    def __sub__(self, other):
        s = []
        if len(self.coef) > len(other.coef):
           for i in range(0, len(other.coef)):
               s.append(self.coef[i]-other.coef[i])
           for i in range(len(other.coef), len(self.coef)):
               s.append(self.coef[i])
        else:
            for i in range(0, len(self.coef)):
                s.append(self.coef[i] - other.coef[i])
            for i in range(len(self.coef), len(other.coef)):
                s.append(- other.coef[i])
        return Polynomial(s)



a = Polynomial([2, 3, 4])
b = Polynomial([1, 4, 2, 2])
print(f'{a}+{b}={a+b}')
print(f'{a}-({b})={a-b}')