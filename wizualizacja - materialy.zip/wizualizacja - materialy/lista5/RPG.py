class Character:
    def __init__(self, name='Unknown', life=0, points=0):
        self.name = name
        if (life > 0) and (life <= 100):
            self.life = life
        else:
            print ('Warning: not correct life, life is set to 0')
            self.life = 0
        if points > 0:
            self.points = points
        else:
            print('Warning: not correct points, points are set to 0')
            self.points = 0

    def change_life(self, life):
        if (life >= 0) and (life <= 100):
            self.life = life

    def __str__(self):
        return str(self.name) + ': life ' + str(self.life) + ', points ' + str(self.points)


class Archer(Character):
    def __init__(self, name='Unknown', life=0, points=0, skill=0):
        Character.__init__(self, name, life, points)
        if skill > 0:
            self.skill = skill

    def __str__(self):
        return Character.__str__(self) + ', skill ' + str(self.skill)

    def attack_power(self):
        return self.skill * self.points * self.life / 100


class Warrior(Character):
    def __init__(self, name='Unknown', life=0, points=0, power=0):
        Character.__init__(self, name, life, points)
        if power > 0:
            self.power = power

    def __str__(self):
        return Character.__str__(self) + ', power ' + str(self.power)

    def attack_power(self):
        if self.life >= 20:
            return self.power * self.points * self.life / 100
        else:
            return self.power * self.points * 1.5


a = Archer('A', 30, 20, 5)
print(a)
a.change_life(120)
print(a)
a.change_life(10)
print(a)
print(a.attack_power())

b = Warrior('W', 30, 20, 5)
print(b)
print(b.attack_power())
b.change_life(10)
print(b)
print(b.attack_power())

c = Character('C',150,30)
print(c)