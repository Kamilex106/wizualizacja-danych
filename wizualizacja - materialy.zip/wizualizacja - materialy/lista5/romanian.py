class Romanian:
    def __init__(self, number):
        if isinstance(number, str):
            self.number = number
            romanian_numerals = {'I': 1, 'V': 5, 'X': 10, 'L': 50, 'C': 100, 'D': 500, 'M': 1000}
            n = 0
            # 4 (IV) and 9 (IX), 40 (XL), 90 (XC), 400 (CD) and 900 (CM)
            number = number.replace('IV', 'IIII')
            number = number.replace('IX', 'VIIII')
            number = number.replace('XL', 'XXXX')
            number = number.replace('XC', 'LXXXX')
            number = number.replace('CD', 'CCCC')
            number = number.replace('CM', 'DCCCC')
            for i in number:
                n += romanian_numerals[i]
            self.value = n
        elif isinstance (number, int):
            self.value = number
            num = [1, 4, 5, 9, 10, 40, 50, 90,
                   100, 400, 500, 900, 1000]
            sym = ["I", "IV", "V", "IX", "X", "XL",
                   "L", "XC", "C", "CD", "D", "CM", "M"]
            i = 12
            s = ''
            while number:
                div = number // num[i]
                number %= num[i]

                while div:
                    s += sym[i]
                    div -= 1
                i -= 1
            self.number = s


    def __str__(self):
        return str(self.number)

    def __add__(self, s):
        return Romanian(self.value+s.value)

    def __sub__(self, s):
        return Romanian(self.value-s.value)

    def __mul__(self, s):
        return Romanian(self.value*s.value)

    def __len__(self):
        return len(self.number)

    def __getitem__(self, item):
        return self.number[item]



print('1984=', Romanian(1984))
print('MCMLXXXIV=', Romanian('MCMLXXXIV').value)
a = Romanian('MCMLXXXIV')
b = Romanian('MXXIV')
print(a-b)
print((a-b).value)