
class Account:
    def __init__(self,  number, balance = 0):
        self.balance = balance
        self.number = number

    def __str__(self):
        return str(self.number) + ': ' + str(self.balance)

    def in_transfer (self, acc, amount = 200):
        self.balance -= amount
        acc.balance += amount

    def out_transfer(self, amount = 100):
        self.balance -= amount

    def in_payment(self, amount = 0):
        self.balance += amount


acc1 = Account ('AM12378', 3000)
acc2 = Account('FG78190')
print(acc1)
print(acc2)
acc1.in_transfer(acc2)
print(acc1)
print(acc2)
acc1.in_payment(30)
print(acc1)


#https://www.w3schools.com/python/python_inheritance.asp
class PrivatAccount (Account):
    def slip_payments(self):
        self.balance -= 1000


class FirmAccount (Account):
    def __init__(self,  number, balance = 100000):
        self.balance = balance
        self.number = number

    def zus_payment(self):
        self.balance-=10000

    def salary(self, *acc):
        for i in acc:
            self.balance -= 2500
            i.balance += 2500


uwm_account = FirmAccount('UWM1234')
print(uwm_account)
my_acc = PrivatAccount ('PR2345', 3000)
another_acc = PrivatAccount('PR4567')
print(my_acc)
print (another_acc)
uwm_account.salary(my_acc,another_acc)
print(uwm_account)
print(my_acc)
print (another_acc)
my_acc.slip_payments()
print(my_acc)
my_acc.in_transfer(another_acc,200)
print(my_acc)
print (another_acc)

