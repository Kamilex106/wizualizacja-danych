print("zad1")
print(2+3)
print(2**3)
print(5<2)
print(9**(1/2))
import Hello
##Hello.hello_world()
a=2.5
b=3
c=10
d=1.5
print(a+c)
print(a*b)
print(c%d)
print(c**b)
print(d<c)
## print(c/x)
## print(b/0)
x=2
print(c/x)
print(b/1)