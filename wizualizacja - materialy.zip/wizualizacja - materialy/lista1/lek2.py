
string = "jakis_przykładowy_string."
print("Znak o indeksie 12:", string[12])
string1 = "Hello"
string2 = "World"
print(string1 + string2)
print(string1 * 3)
print("Dlugosc stringu:", len(string))
print("Ostatni znak stringu:", string[-1])
