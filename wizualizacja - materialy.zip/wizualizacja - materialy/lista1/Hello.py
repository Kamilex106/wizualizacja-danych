print("Witaj świecie!")
