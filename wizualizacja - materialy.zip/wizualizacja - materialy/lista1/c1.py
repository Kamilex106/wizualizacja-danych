var1 = 2
var2 = 3
var1 += 2
var3 = var1
var1 *= 3
var4 = var1/var2
##print (var1+=2)
print(var1, var2,var3, var4)
var4 /=2
print('var4 = ', var4)