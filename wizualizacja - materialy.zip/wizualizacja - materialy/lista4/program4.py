#cw.1
names = ["michal", "nela", "Ola", "przemek"]
namesW = [x.capitalize() for x in names]
print(namesW)

namesL=[x for x in names if "l" in x]
#print(namesL)


# names_A= [x for x in names]
# names_A_tuple = (for x in names_A)
# print(names_A_tuple)

names_tuple = tuple([name.strip() for name in names if (name.strip().endswith('a')) and  name[0].isupper()])
#print(names_tuple)

total_length = 0
for name in names:
    total_length += len(name.strip())
#print(total_length)




