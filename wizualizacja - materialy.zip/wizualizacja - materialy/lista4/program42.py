#cw.2
def iloczyn(*values):
    sum=1
    for n in values:
        sum = sum*n
    return(sum)

#print(iloczyn(5,5,2))

def potegi(n,*values):
    sum=0
    for x in values:
        x = x**n
        sum+=x
    return sum


#print(potegi(2,2,3))

def mean(first, *values):
    return (first +sum(values)) / (1+len(values))


#print(mean(2, 3, 4, 6))

import math
def gmean(*args):
    result = 1
    for num in args:
        result *= num
    return math.pow(result, 1/len(args))

#print(gmean(5,4))

def total_length(*args):
    length = 0
    for s in args:
        length += len(s)
    return length


# print(total_length("kwiat","dom"))