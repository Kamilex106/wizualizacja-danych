import math
#cw. 3


def wyswietl_numer_telefonu(**kwargs):
    for imie, numer in kwargs.items():
        print(f"{imie} ma numer telefonu {numer}")

# wyswietl_numer_telefonu(Kasia="123-456-789")
# wyswietl_numer_telefonu(Tomek="987-654-321")



def oblicz_statystyki(**kwargs):
    zarobki = list(kwargs.values())
    srednia_arytmetyczna = sum(zarobki) / len(zarobki)
    procentowe_wzrosty = [zarobek / srednia_arytmetyczna for zarobek in zarobki]
    srednia_geometryczna = math.prod(procentowe_wzrosty) ** (1/len(procentowe_wzrosty))
    return srednia_arytmetyczna, srednia_geometryczna


wynik1 = oblicz_statystyki(styczen=1000, luty=1100, marzec=1200)
wynik2 = oblicz_statystyki(kwiecien=2000, maj=2500, czerwiec=3000, lipiec=3500)
print(wynik1)
print(wynik2)