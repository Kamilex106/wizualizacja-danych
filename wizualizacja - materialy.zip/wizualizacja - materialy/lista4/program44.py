pesel = input("Podaj numer PESEL: ")

if len(pesel) != 11 or not pesel.isdigit():
    print("Nieprawidłowy format PESEL")
else:
