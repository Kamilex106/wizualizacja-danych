lista1 = []
for i in range(1,11):
    lista1.append(i)
print(lista1)

lista2 = []
for i in range(0,21):
    if i % 2 == 0:
        lista2.append(i)
print(lista2)

lista3 = []
for i in range(1,11):
    num = pow(i,2)
    lista3.append(num)
print(lista3)

lista4 = []
for i in range(1,11):
    num = 0
    lista4.append(num)
print(lista4)

lista5 = []
for i in range(1,11):
    if i % 2 == 0:
        lista5.append(1)
    else:
        lista5.append(0)
print(lista5)

lista6 = []
for i in range(1,10):
    if i < 5:
        lista6.append(i)
    else:
        lista6.append(i-5)
print(lista6)

