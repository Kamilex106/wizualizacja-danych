from typing import List

def iloczyn(lis):
    i = 0
    wynik = 1
    dlugosc =len(lis)
    while i < dlugosc:
        wynik *= lis[i]
        i += 1

    return wynik

lista: List[int] = [1, 2, 3, 4, 5]

print(iloczyn(lista))