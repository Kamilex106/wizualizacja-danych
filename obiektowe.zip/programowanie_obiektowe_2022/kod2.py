from typing import List

lista: List[int] = []
i=1

while i<11:
    lista.append(i)
    i += 1

print(lista)