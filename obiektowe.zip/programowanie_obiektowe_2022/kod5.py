from typing import Tuple

def minmax(krotka):
    dlugosc =len(krotka)
    i = 0

    #max

    wynik1 =0
    while i != dlugosc-1:
        if wynik1 < krotka[i+1]:
            wynik1 = krotka[i+1]
        i += 1

    #min

    i = 0
    wynik2=krotka[0]
    while i != dlugosc-1:
        if wynik2 > krotka[i+1]:
            wynik2 = krotka[i+1]
        i += 1

    return(wynik1, wynik2)

krotka: Tuple[int] = (1, 2, 3, -12, 5, 6, 100, 7, 8, 9, 10, 11000)

print(minmax(krotka))