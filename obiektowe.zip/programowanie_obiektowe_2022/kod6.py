from typing import List
                                    #1 - 4 + 16 - 9 + 9 - 7 + 4 - 9 + 11 = -2
def fun(lis):
    dlugosc = len(lis)
    i=0
    wynik=lis[i]
    while i<dlugosc:
        wynik-=lis[i+1]
        wynik += lis[i + 2]
        i+=1
    return wynik





lista: List[int] = [1, 4, 16, 9, 9, 7, 4, 9, 11]
print(fun(lista))