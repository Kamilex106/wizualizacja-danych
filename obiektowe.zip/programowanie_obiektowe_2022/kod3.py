from typing import List

def ile_ujemnych(lista):
    i = 0
    wynik = 0
    dlugosc=len(lista)
    while i < dlugosc:
        if lista[i] < 0:
            wynik += 1
        i+=1

    return wynik

lista: List[int] = [-1, 3, 0, -53, 69]

print(ile_ujemnych(lista))
