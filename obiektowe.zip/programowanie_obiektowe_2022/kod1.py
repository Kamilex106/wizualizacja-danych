from typing import List

l: List[int] = []
for a in range(10):
    l.append(a+1)

print(l)
#########################################################
li: List[int] = []
c=0
for b in range(11):
    li.append(c)
    c+=2
print(li)
#########################################################
lis: List[int] = []
temp = e = 1
for d in range(10):
    lis.append(temp)
    e += 1
    temp = e
    temp *= temp
print(lis)
#########################################################
list: List[int] = []
g=0
for f in range(10):
    list.append(g)
print(list)
#########################################################
list1: List[int] = []
i=0
for h in range(10):
    list1.append(i)
    if i == 0:
        i=1
    else:
        i=0
print(list1)
#########################################################
list2: List[int] = []
k=0
for j in range(10):
    list2.append(k)
    k+=1
    if k == 5:
        k=0
print(list2)
