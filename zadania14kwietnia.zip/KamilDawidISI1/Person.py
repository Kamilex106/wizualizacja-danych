import datetime

class Preson:
    def __init__(self, imie, nazwisko, pesel):
        self.imie = imie
        self.nazwisko = nazwisko
        self.pesel = pesel

        mnozniki = [9,7,3,1,9,7,3,1,9,7]
        s = sum(w * int(c) for w, c in zip(mnozniki, pesel))
        if s%10 !=0:
            print("Bledny numer PESEL")
            self.imie = ''
            self.nazwisko = ''
            self.pesel=''
            return

        rok = int(pesel[0:2])
        miesiac = int(pesel[2:4])
        dzien = int(pesel[4:6])
        plec = int(pesel[9])

        if miesiac > 80 and miesiac < 93:
            miesiac -= 80
        elif miesiac > 20 and miesiac < 33:
            miesiac -= 20
        elif miesiac > 40 and miesiac < 53:
            miesiac -= 40
        elif miesiac > 60 and miesiac < 73:
            miesiac -= 60

        if plec % 2 ==0:
            self.plec = 'Kobieta'
            self.data_urodzenia = datetime.date(1900+rok, miesiac, dzien)
        else:
            self.plec = 'Mezczyzna'
            self.data_urodzenia = datetime.date(2000+rok, miesiac, dzien)

        self.wiek = (datetime.date.today()-self.data_urodzenia) // datetime.timedelta(days=365)

    def wyswietlanie(self):
        if self.imie == '':
            print("Nie istnieje")
            return
        print("Imie: {}".format(self.imie))
        print("Nazwisko: {}".format(self.nazwisko))
        print("PESEL: {}".format(self.pesel))
        print("Plec: {}".format(self.plec))
        print("Data urodzenia: {}".format(self.data_urodzenia))
        print("Wiek: {}".format(self.wiek))


Ja = Preson('Kamil', 'Dawid', '02212803510')
Ja.wyswietlanie()