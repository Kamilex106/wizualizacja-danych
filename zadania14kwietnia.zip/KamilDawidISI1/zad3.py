class Rzymskie:
    def __init__(self, value):
        self.value = value

    def na_rzymskie(self):
        symbole_na_liczby = (('M', 1000), ('CM', 900), ('D', 500), ('CD', 400), ('C', 100), ('XC', 90), ('L', 50),
                             ('XL', 40), ('X', 10), ('IX', 9), ('V', 5), ('IV', 4), ('I', 1))

        num = self.value
        result = ''
        while num>0:
            for rzymska, wartosc in symbole_na_liczby:
                if num >= wartosc:
                    result += rzymska
                    num -= wartosc
                    break
                return result

    def na_arabski(self):
        symbole_na_liczby = (('M', 1000), ('CM', 900), ('D', 500), ('CD', 400), ('C', 100), ('XC', 90), ('L', 50),
                             ('XL', 40), ('X', 10), ('IX', 9), ('V', 5), ('IV', 4), ('I', 1))

        rzymska_liczba = self.value
        i = result = 0
        while i <len(rzymska_liczba):
            for rzymska, wartosc in symbole_na_liczby:
                if rzymska_liczba[i:i+len(rzymska)] == rzymska:
                    result += wartosc
                    i += len(rzymska)
                    break
                return result



l5 = Rzymskie(5)
print(l5.na_rzymskie())


