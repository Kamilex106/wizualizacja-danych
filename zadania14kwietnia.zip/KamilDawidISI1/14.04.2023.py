class Hero:
    def __init__(self, name, health=100, pot=0):
        self.name = name
        self.health = health
        self.pot = pot

        if self.health > 100:
            self.health=100
            print("Bohater nie może miec więcej niż 100% HP. Przypisano podstawowy poziom zdrowia.")

    def received_damage(self, player_damage):
        self.health -= player_damage
        if self.health <= 0:
            print("Twoja postac umarla. Zaplac 5634673 cebulionow by ja wskrzesic")
        else:
            print("Twoja postac otrzymala: "+str(player_damage)+" dmg i pozostalo jej: "+str(self.health)+" HP.")



class Archer(Hero):
    def __init__(self, name='Anon', health=100, pot=0, agility=0):
        super().__init__(name, health, pot)
        self.agility = agility

    def power_of_attack(self):
        damage = self.agility * self.pot * self.health / 100.0
        return damage


class Warrior(Hero):
    def __init__(self, name='Ragnar', health=100, pot=0, strength=0):
        super().__init__(name, health, pot)
        self.strength = strength


    def power_of_attack(self):
        if self.health < 20:
            damage = self.strength * self.pot * 1.5
        else:
            damage = self.strength * self.pot * (self.health) / 100.0
        return damage

Adrian = Archer('Adrian', pot=5, agility=5)
Adrian2 = Archer(health=50, pot=5, agility=5)

print(Adrian.power_of_attack())
print(Adrian2.name)
print(Adrian2.power_of_attack())


Maciek = Warrior('MaciekKOX2007', health=19, pot=3, strength=10)
Rysiek = Warrior(health=100, pot=4, strength=9)

print(Maciek.name)
print(Maciek.power_of_attack())
print(Rysiek.name)
print(Rysiek.power_of_attack())


Adrian.received_damage(Maciek.power_of_attack())
Adrian.received_damage(Maciek.power_of_attack())
Adrian.received_damage(Maciek.power_of_attack())

print(Adrian.health)


