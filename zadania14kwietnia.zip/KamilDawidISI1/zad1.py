class Fruit:
    def __init__(self, color, weight = 0.5):
        self.color = color
        self.weight = weight

class Apple(Fruit):


    def isfresh(self):
        if self.color == "red" or self.color == "green":
            return True
        else:
            return False

class Banana(Fruit):


    def isfresh(self):
        if self.color == "yellow":
            return True
        else:
            return False

class Orange(Fruit):


    def isfresh(self):
        if self.color == "orange":
            return True
        else:
            return False



jablko = Apple("red")
print("Czy jablka są świerze: "+str(jablko.isfresh())+", a mamy ich "+ str(jablko.weight)+"kg")

pomarancza = Orange("green", 6)
print("Czy pomarancze są świerze: "+str(pomarancza.isfresh())+", a mamy ich "+ str(pomarancza.weight)+"kg")

banan = Banana("yellow", 2)

print("Czy banany są świerze: "+str(banan.isfresh())+", a mamy ich "+ str(banan.weight)+"kg")

