def sprawdz_pesel(pesel):
    if len(pesel) != 11:
        print("Pesel nie ma 11 znakow")
        return False
    if not pesel.isdigit():
        print("Pesel nie sklada sie z cyfr")
        return False
    rok = int(pesel[0:2])
    miesiac = int(pesel[2:4])
    dzien = int(pesel[4:6])
    if miesiac > 80:
        rok += 1800
        miesiac -= 80
    elif miesiac > 60:
        rok += 2200
        miesiac -= 60
    elif miesiac>40:
        rok+=2100
        miesiac -=40
    elif miesiac > 20:
        rok += 2000
        miesiac -=20
    else:
        rok +=1900
    plec = "kobieta" if int(pesel[-2]) %2 == 0 else "meszczyzna"
    return (dzien, miesiac, rok, plec)


pesel = input("Podaj pesel: ")
wynik=sprawdz_pesel(pesel)
if wynik:
    dzien, miesiac, rok, plec= wynik
    print(f"Data urodzenia {dzien}:{miesiac}:{rok} plec {plec}")
