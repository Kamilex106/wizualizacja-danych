def A(names):
    nowa_lista = []
    for x in names:
        x = x.strip()
        x = x.split(' ')
        x = ''.join(x)
        x = x.capitalize()
        nowa_lista.append(x)
    print(nowa_lista)


def B(names):
    nowa_lista = []
    for x in names:
        x = x.strip()
        x = x.split(' ')
        x = ''.join(x)
        if (x.find('l') >= 0):
            nowa_lista.append(x)
    print(nowa_lista)


def C(names):
    nowa_lista = []
    for x in names:
        x = x.strip()
        x = x.split(' ')
        x = ''.join(x)
        x = x.capitalize()
        if(x.endswith('a')):
            nowa_lista.append(x)
    tupla = tuple(nowa_lista)
    print(tupla)


def D(names):
    litery = 0
    nowa_lista = []
    for x in names:
        x = x.strip()
        x = x.split(' ')
        x = ''.join(x)
        litery += len(x)
    print(litery)


names = [" michal ", " n e l a ", " o l a ", " przemek "]
A(names)
B(names)
C(names)
D(names)