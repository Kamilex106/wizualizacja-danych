import phonenumbers

phonenumbers.phone_numbers['David'] = '456-789-012'
del phonenumbers.phone_numbers['Jan']
phonenumbers.phone_numbers['Anna'] = '111-222-333'
#print(phonenumbers.phone_numbers)

def print_phone_numbers(phone_dict):
    for name, number in phone_dict.items():
        print(f"{name} ma numer {number}")
#print_phone_numbers(phonenumbers.phone_numbers)


def day_name_to_eng(day_name):
    days = {'poniedzialek': 'Monday', 'wtorek': 'Tuesday', 'sroda': 'Wednesday',
            'czwartek': 'Thursday', 'piatek': 'Friday', 'sobota': 'Saturday', 'niedziela': 'Sunday'}
    return days[day_name.lower()]

def day_name_to_pl(day_name):
    days = {'Monday': 'poniedzialek', 'Tuesday': 'wtorek', 'Wednesday': 'sroda',
            'Thursday': 'czwartek', 'Friday': 'piatek', 'Saturday': 'sobota', 'Sunday': 'niedziela'}
    return days[day_name]


#print(day_name_to_pl("Tuesday"))

def sort_months(months_list):
    # słownik z kolejnością miesięcy
    month_order = {
        'January': 1,
        'February': 2,
        'March': 3,
        'April': 4,
        'May': 5,
        'June': 6,
        'July': 7,
        'August': 8,
        'September': 9,
        'October': 10,
        'November': 11,
        'December': 12
    }
    # sortowanie listy miesięcy według kolejności zdefiniowanej w słowniku
    return sorted(months_list, key=lambda month: month_order[month])

def roman_to_arabic(roman_numeral):
    # słownik z wartościami rzymskich cyfr
    roman_numerals = {
        'I': 1,
        'V': 5,
        'X': 10,
        'L': 50,
        'C': 100,
        'D': 500,
        'M': 1000
    }
    arabic_num = 0

    for i in range(len(roman_numeral)):
        if i > 0 and roman_numerals[roman_numeral[i]] > roman_numerals[roman_numeral[i-1]]:
            arabic_num += roman_numerals[roman_numeral[i]] - 2 * roman_numerals[roman_numeral[i-1]]
        else:
            arabic_num += roman_numerals[roman_numeral[i]]
    return arabic_num



def arabic_to_roman(arabic_num):
    # lista z wartościami rzymskich cyfr i odpowiadającymi im liczbami
    roman_values = [
        ('M', 1000),
        ('CM', 900),
        ('D', 500),
        ('CD', 400),
        ('C', 100),
        ('XC', 90),
        ('L', 50),
        ('IX', 9),
        ('V', 5),
        ('IV', 4),
        ('I', 1)
    ]
    roman_num = ''
    # iteracja po liście wartości rzymskich
    for letter, value in roman_values:
        # dodajemy tyle rzymskich cyfr, ile razy wartość danej cyfry mieści się w liczbie arabskiej
        while arabic_num >= value:
            roman_num += letter
            arabic_num -= value
    return roman_num


# zamiana liczby rzymskiej na arabską
roman_num = 'MCMXCVI'
arabic_num = roman_to_arabic(roman_num)
#print(arabic_num)
# 1996

# zamiana liczby arabskiej na rzymską
arabic_num = 3999
roman_num = arabic_to_roman(arabic_num)
#print(roman_num)
# 'MMMCMXCIX'


def is_palindrome(word):
    return word == word[::-1]

# print(is_palindrome("radar"))
# print(is_palindrome("python"))
