import pandas as pd
import matplotlib.pyplot as plt


df = pd.read_csv("jajka2023.csv", sep=";", decimal=",")
df.boxplot(column=["Górny Śląsk", "Bydgoszcz", "Lublin", "Warszawa", "Trójmiasto", "Kraków"], by="Sklep")
plt.show()
