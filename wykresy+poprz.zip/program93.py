f = open('tekst1.txt', 'r+',encoding='utf-8')
s= f.read()
print(s)
print(type(s))

f.write('nowy tekst')


f.close()

