import numpy as np

with open('jajka2023.csv', 'r', encoding='utf-8') as f:
    data = np.genfromtxt((line.replace(',', '.') for line in f), delimiter=';', dtype=str)

# Extract the city names and store them in a separate array
cities = data[1:, 0]

# Convert the data to floats, ignoring errors for empty values
prices = np.zeros((data.shape[0] - 1, data.shape[1] - 1))
for i in range(1, data.shape[0]):
    for j in range(1, data.shape[1]):
        try:
            prices[i - 1, j - 1] = float(data[i, j])
        except ValueError:
            pass

# Calculate the average price
avg_price = np.mean(prices)

# Find the cheapest and most expensive cities and stores
min_indices = np.where(prices == np.min(prices))
max_indices = np.where(prices == np.max(prices))

# Create arrays to store the results
cheapest = np.array([(cities[min_indices[0][i]], data[0, min_indices[1][i] + 1]) for i in range(len(min_indices[0]))])
most_expensive = np.array([(cities[max_indices[0][i]], data[0, max_indices[1][i] + 1]) for i in range(len(max_indices[0]))])

print('Średnia cena: {:.2f} zł'.format(avg_price))


import pandas as pd
#
data = pd.read_csv('jajka2023.csv', sep=';', index_col=0, encoding='UTF-8')
data2 = data.stack()
data3 = data2.str.replace(',', '.').astype('float')
srednia = data3.mean()
minCena = data3.min()
maxCena = data3.max()

print(data3[data3 == minCena])
print(data3[data3 == maxCena])


import matplotlib.pyplot as plt

# Wczytanie danych z pliku CSV
df = pd.read_csv("jajka2023.csv", sep=";", decimal=",")

# Utworzenie wykresu pudełkowego cen jajek w zależności od sklepu i miasta
df.boxplot(column=["Górny Śląsk", "Bydgoszcz", "Lublin", "Warszawa", "Trójmiasto", "Kraków"], by="")

# Wyświetlenie wykresu
plt.show()
