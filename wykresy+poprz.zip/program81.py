# import numpy as np
# a = np.arange(10, 40, 2)
# print(a)
#
# print(np.shape(a))
#
# a = np.resize(a,(20))
# print(np.shape(a))
#
# a = np.resize(a,(6))
# print(np.shape(a))
# print(a)
#
# a = np.arange(10, 40, 2)
# print(a)
# #
# # print("a")
# # a = np.array([[3, 4, 5], [-3, 4, 8], [3, 2, 9]])
# # print(a)
# # print("b")
# # b = np.reshape(a, (1, 9))
# # print(b)
# # print("c")
# # c = a.reshape(9)
# # print(c)
#
# k = 0
# for i in a:
#     a[k]+=3
#     k+=1
#
# print(a)
#
# a = np.arange(10, 40, 2)
# print(a)
#
# k = 0
# for i in a:
#     a[k]*=a[k]
#     k+=1
#
# print(a)
#
#
# a = np.arange(10, 40, 2)
#
# a[a % 6 == 2] = 0


import numpy as np

def change(A, x):
    result = A.copy()
    result[result == 0] = x
    return result


my_array = np.arange(10, 40, 2)


print("Rozmiar tablicy:", my_array.shape)


my_array = np.reshape(my_array, (3, 5))
print("Zmieniony rozmiar tablicy:\n", my_array)

my_array = my_array + 3
print("Tablica po dodaniu 3:\n", my_array)


my_array = my_array * 2
print("Tablica po zwielokrotnieniu 2 razy:\n", my_array)


my_array[my_array % 6 == 2] = 0
print("Tablica po zamianie liczb podzielnych przez 6 z resztą 2 na zero:\n", my_array)


new_array = change(my_array, 99)
print("Nowa tablica z zamienionymi zerami na 99:\n", new_array)
print("Oryginalna tablica (niezmieniona):\n", my_array)
