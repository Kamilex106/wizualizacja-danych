Nazwa pliku: world_population.csv
Opis: Dane dotyczące populacji świata, wraz z podziałem na kraje i rok.
Źródło: https://datahub.io/core/population
Licencja: Public Domain (https://creativecommons.org/publicdomain/zero/1.0/)

Nazwa pliku: car_prices.csv
Opis: Dane dotyczące cen samochodów używanych z różnymi cechami, takimi jak marka, model, rok produkcji, przebieg i paliwo.
Źródło: https://www.kaggle.com/CooperUnion/cardataset
Licencja: Open Database License (ODbL) (https://opendatacommons.org/licenses/odbl/1.0/)


Nazwa pliku: worldwide_happiness.csv
Opis: Dane dotyczące poziomu szczęścia obywateli różnych krajów na świecie, na podstawie World Happiness Report.
Źródło: https://www.kaggle.com/unsdsn/world-happiness
Licencja: Open Database License (ODbL) (https://opendatacommons.org/licenses/odbl/1.0/)

Nazwa pliku: video_game_sales.csv
Opis: Dane dotyczące sprzedaży gier wideo na różnych platformach i w różnych regionach świata.
Źródło: https://www.kaggle.com/gregorut/videogamesales
Licencja: Open Database License (ODbL) (https://opendatacommons.org/licenses/odbl/1.0/)

Nazwa pliku: cryptocurrency_prices.csv
Opis: Dane dotyczące historycznych cen kryptowaluty Bitcoin
Źródło: https://www.kaggle.com/sudalairajkumar/cryptocurrencypricehistory
Licencja: CC0: Public Domain (https://creativecommons.org/publicdomain/zero/1.0/)